package com.klef.rest;

public class Student {
	
	int id;
	String name;
	Double cgpa;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getCgpa() {
		return cgpa;
	}
	public void setCgpa(Double cgpa) {
		this.cgpa = cgpa;
	}
	
	public String toString() {
		return ("ID: " + id + ", NAME: " + name + ", CGPA: " + cgpa);
	}

}
