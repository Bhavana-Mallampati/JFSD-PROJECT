package com.klef.rest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Booking {
    public static void main(String[] args) {
        // Database connection parameters
       String url = "jdbc:mysql://your_database_host:3306/jdbc";
        String username = "root";
        String password = "Bhavana@320";

        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the database connection
            Connection connection = DriverManager.getConnection(url, username, password);

            // SQL query to insert data into the database
            String insertQuery = "INSERT INTO ad_booking (name, email, service, preferred_date, comments) VALUES (?, ?, ?, ?, ?)";

            // Sample form data
            String name = "John Doe";
            String email = "johndoe@example.com";
            String service = "Social Media Marketing";
            String date = "2023-11-10";
            String comments = "Please promote our new product.";

            // Create a prepared statement and set parameters
            PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, service);
            preparedStatement.setString(4, date);
            preparedStatement.setString(5, comments);

            // Execute the SQL query
            int rowsInserted = preparedStatement.executeUpdate();

            if (rowsInserted > 0) {
                System.out.println("Data inserted successfully.");
            } else {
                System.out.println("Failed to insert data.");
            }

            // Close the resources
            preparedStatement.close();
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}
