package com.klef.rest;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class SignupServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String fullName = request.getParameter("full_name");
        String email = request.getParameter("email");
        String mobileNumber = request.getParameter("mobile_number");
        String password = request.getParameter("psw");
        String city = request.getParameter("city");

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            // Establish a database connection (update with your database credentials)
            String jdbcUrl = "jdbc:mysql://localhost:3306/jdbc";
            String dbUser = "root";
            String dbPassword = "Bhavana@320";
            conn = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);

            // Define your SQL query to insert data into the user table
            String sql = "INSERT INTO user (full_name, email, mobile_number, password, city) VALUES (?, ?, ?, ?, ?)";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, fullName);
            stmt.setString(2, email);
            stmt.setString(3, mobileNumber);
            stmt.setString(4, password);
            stmt.setString(5, city);

            // Execute the insert query
            stmt.executeUpdate();

            // Redirect to a success page or provide a success message
            response.sendRedirect("/success");
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database errors
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}

