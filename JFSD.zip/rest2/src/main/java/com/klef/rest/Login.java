package com.klef.rest;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Login extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the email and password parameters from the request
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        boolean validCredentials = true; 

        if (validCredentials) {
            response.sendRedirect("/success"); 
        } else {
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<html><body><h2>Invalid credentials</h2></body></html>");
        }
    }
}
