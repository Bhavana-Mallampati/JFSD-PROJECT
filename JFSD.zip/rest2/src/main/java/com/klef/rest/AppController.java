package com.klef.rest;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


@Controller
public class AppController {
	
	
	public static Map<Integer, Student> student = new HashMap<>();
	static {
		Student s1 = new Student();
		s1.setId(1);
		s1.setName("name 1");
		s1.setCgpa(9.0);
		student.put(s1.getId(), s1);
		
		Student s2 = new Student();
		s2.setId(2);
		s2.setName("name 2");
		s2.setCgpa(9.3);
		student.put(s2.getId(), s2);
	}
	
	
	
	@GetMapping("")
	@ResponseBody
	public String fn(@RequestParam(value="name", defaultValue = "KLEF")String name) {
		return ("First web APP"+name);
	}
    
    @GetMapping("/second/{name}")
    @ResponseBody
	public String fn2(@PathVariable("name")String name) {
		return ("Second"+name);
	}
		
	@GetMapping("/home")
	public String fun3() {
		return "home";
	}
	

	@GetMapping("/show")
	public String show(Model m) {
		m.addAttribute("stu", student);
		return "show";
	}		
	@GetMapping("/jspinsert")
	public String jspInsert(Model m) {
		m.addAttribute("command", new Student());
		return "insert";
	
	}
	 @GetMapping("/login")
	    public String login() {
	        return "login"; 
	    }
	 @GetMapping("/suc")
	    public String suc() {
	        return "suc"; 
	    }
	 @GetMapping("/team")
	    public String team() {
	        return "team"; 
	    }
	 @GetMapping("/sentemail")
	    public String sentemail() {
	        return "sentemail"; 
	    }
	 @GetMapping("/booking")
	    public String booking() {
	        return "booking"; // Assuming "login" is the name of your JSP file
	    }
	 @GetMapping("/paymet")
	    public String paymet() {
	        return "paymet"; // Assuming "login" is the name of your JSP file
	    }
	 @GetMapping("/process_booking")
	    public String process_booking() {
	        return "process_booking"; // Assuming "login" is the name of your JSP file
	    }
	 @GetMapping("/us")
	    public String us() {
	        return "us"; // Assuming "login" is the name of your JSP file
	    }
	 @GetMapping("/feedsuc")
	    public String feedsuc() {
	        return "feedsuc"; // Assuming "login" is the name of your JSP file
	    }
	 @GetMapping("/paysuc")
	    public String paysuc() {
	        return "paysuc"; // Assuming "login" is the name of your JSP file
	    }
	 @GetMapping("/setting")
	    public String setting() {
	        return "setting"; // Assuming "login" is the name of your JSP file
	    }
	 @GetMapping("/feedback")
	    public String feedback() {
	        return "feedback"; // Assuming "login" is the name of your JSP file
	    }
	 @GetMapping("/signsucc")
	    public String signsucc() {
	        return "signsucc"; // Assuming "login" is the name of your JSP file
	    }
	 @GetMapping("/review")
	    public String review() {
	        return "review"; // Assuming "login" is the name of your JSP file
	    }
	 @GetMapping("/v")
	    public String v() {
	        return "v"; // Assuming "login" is the name of your JSP file
	    }
	 @GetMapping("/Ad")
	    public String Ad() {
	        return "Ad"; // Assuming "login" is the name of your JSP file
	    }
	 @GetMapping("/admin")
	    public String admin() {
	        return "admin"; // Assuming "login" is the name of your JSP file
	    }
	 @GetMapping("/forgotpass")
	    public String forgotPassword() {
	        return "forgotpass"; // "forgotpass" refers to forgotpass.jsp
	    }
	@PostMapping("/save")
	public String insertStudent(@ModelAttribute("stu") Student s, Model m) {
		student.put(s.getId(), s);
		m.addAttribute("stu", student);
		return "show";
	}
	}


