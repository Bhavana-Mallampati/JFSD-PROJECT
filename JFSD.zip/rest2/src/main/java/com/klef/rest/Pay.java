package com.klef.rest;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class Pay extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String cardNumber = request.getParameter("cardNumber");
        
        if (isValidCreditCardNumber(cardNumber)) {
            // Card number is valid, you can proceed with payment processing.
            response.sendRedirect("/paysuc"); // Redirect to payment success page
        } else {
            // Invalid card number, handle accordingly
            response.sendRedirect("/paymentform"); // Redirect back to the payment form with an error message
        }
    }

   

        private boolean isValidCreditCardNumber(String cardNumber) {
            
            return false; // Return true if the card number is valid
        }
    }

